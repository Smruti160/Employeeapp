<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\Project;
use App\Models\Employeeproject;
use DB;
use Session;

class SitesController extends Controller
{
   public function dashboard(){
    return view('dashboard');
   }

   public function add_employee(Request $request){
        if(isset($request->email)){
            $email=trim($request->email);
            $name=trim($request->name);
            $company=trim($request->company);
            $is_exist=Employee::where('email', $email)->count();
            
            if($is_exist>0){
                return redirect()->back()->with('fail', 'User already exist');
            }else{
                $add=new Employee();
                $add->email=$email;
                $add->emp_name=$name;
                $add->company=$company;
                $add->regd_at=date('y-m-d');
                $add->save();
                return redirect()->back()->with('success', 'User added successfully');
            }
        }
        return view('add_employee');
   }


   public function manage_employee(Request $request){
     $datas=Employee::orderby('emp_name')->get();
    return view('manage_employee', compact('datas'));
   }

   public function edit_employee($id,Request $request){
    $data=Employee::where('id', $id)->first();
        if(isset($request->email)){
            $email=trim($request->email);
            $name=trim($request->name);
            $company=trim($request->company);
          
                $add=Employee::where('id', $id)->first();
                $add->email=$email;
                $add->emp_name=$name;
                $add->company=$company;
                $add->save();
                return redirect()->back()->with('success', 'User Updated successfully');
            
        }
        return view('edit_employee', compact('data'));
   }

   public function delete_employee($id){
        Employee::find($id)->delete();
        return redirect('/manage_employee')->with('success', 'User deleted successfully');
   }


   ///////////project

   public function add_project(Request $request, $id=null){

        
        if(isset($request->project_name)){
            if($id==null){
                $project_name=$request->project_name;
                $is_exist=Project::where('project_name', $project_name)->count();
                if($is_exist>0){
                    Session::flash('fail', 'This project name is already exist');
                }else{
                        $add=new Project();
                        $add->project_name=$project_name;
                        $add->save();
                       
                    return redirect('add_project')->with('success', 'Added Successfully');
                }
            }else{
                 $project_name=$request->project_name;
                
                    $edit=Project::find($id);
               
                    $edit->project_name=$project_name;
                    $edit->save();
               return redirect('add_project')->with('success', 'Project name name updated successfully'); 
                 
               
            }
            
    }
        $datas=Project::orderby('project_name')->get();
        $edit_project=Project::where('id',$id)->first();
        return view('add_project', compact('datas', 'edit_project'));
    }

    public function delete_project($id){
        Project::find($id)->delete();
        return redirect('/add_project')->with('success', 'User deleted successfully');
   }

   /////////

   public function assign_project(Request  $request){
    if(isset($request->emp_id)){
        $add=new Employeeproject();
        $add->emp_id=$request->emp_id;
        $add->project_id=$request->project_id;
        $add->project_report=$request->project_report;
        $add->assign_date=date('Y-m-d');
        $add->save();
        return redirect()->back()->with('success', 'Task assigned successfully');
    }
    $employees=Employee::orderby('emp_name')->get();
    $projects=Project::orderby('project_name')->get();
    return view('assign_project', compact('employees', 'projects'));
   }

   public function manage_assign_project(Request $request){
        $datas=DB::select('select employees.emp_name, employees.company, employees.email, employeeprojects.id, projects.project_name, employeeprojects.project_report FROM employeeprojects INNER JOIN employees ON employeeprojects.emp_id = employees.id INNER JOIN projects ON employeeprojects.project_id = projects.id');
        return view('manage_assign_project', compact('datas'));
   }

   public function edit_assign_project($id,Request  $request){
    if(isset($request->emp_id)){
        $add=Employeeproject::where('id', $id)->first();
        $add->emp_id=$request->emp_id;
        $add->project_id=$request->project_id;
        $add->project_report=$request->project_report;
        $add->assign_date=date('Y-m-d');
        $add->save();
        return redirect('/manage_assign_project')->with('success', 'Task updated successfully');
    }
        
    $data=Employeeproject::where('id', $id)->first();
    $employees=Employee::orderby('emp_name')->get();
    $projects=Project::orderby('project_name')->get();
    return view('edit_assign_project', compact('employees', 'projects', 'data'));
   }

   public function delete_assign_project($id){
    Employeeproject::find($id)->delete();
     return redirect('/manage_assign_project')->with('success', 'Task deleted successfully');
   }

   
}
