<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SitesController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::any('/', [SitesController::class, 'dashboard']);
Route::any('/add_employee', [SitesController::class, 'add_employee']);
Route::any('/manage_employee', [SitesController::class, 'manage_employee']);
Route::any('/edit_employee/{id}', [SitesController::class, 'edit_employee']);
Route::any('/delete_employee/{id}', [SitesController::class, 'delete_employee']);
Route::any('/add_project/{id?}', [SitesController::class, 'add_project']);
Route::any('/delete_project/{id}', [SitesController::class, 'delete_project']);
Route::any('/assign_project', [SitesController::class, 'assign_project']);
Route::any('/manage_assign_project', [SitesController::class, 'manage_assign_project']);
Route::any('/edit_assign_project/{id}', [SitesController::class, 'edit_assign_project']);
Route::any('/delete_assign_project/{id}', [SitesController::class, 'delete_assign_project']);
