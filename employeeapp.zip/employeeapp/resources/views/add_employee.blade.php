<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Employee Project</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

</head>
<body>
	
	<div class="wrapper">
		<div class="container">
			<div class="header">
				<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                    <div class="container-fluid">
    <a class="navbar-brand" href="#">Task</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="{{url('/')}}">Home</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Employee
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="{{url('/')}}/add_employee">Add Employee</a></li>
            <li><a class="dropdown-item" href="{{url('/')}}/manage_employee">Manage Employee</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Project
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="{{url('/')}}/add_project">Manage Project</a></li>
            <li><a class="dropdown-item" href="{{url('/')}}/assign_project">Assign Project</a></li>
            <li><a class="dropdown-item" href="{{url('/')}}/manage_assign_project">Manage Assign Project</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
			</div>
      <div class="row">
            <div class="col-xl-12">
                <div class="breadcrumb-holder">
                    <h1 class="main-title float-left">Add Employees</h1>
                  <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
                        <li class="breadcrumb-item active">Add Employees</li>
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

			<div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-3">

                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            {{csrf_field()}}
                            <div class="col-md-12 row">
                              @if(Session::get('success'))
                                  <div class="alert alert-success alert-dismissible fade show" role="alert">
                                  {{Session::get('success')}}
                                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                          </button>
                                  </div>
                                @endif
                                @if(Session::get('fail'))
                                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                  {{Session::get('fail')}}
                                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                                          </button>
                                  </div>
                                @endif
                              
                                <div class="form-group col-md-6 mt-3">
                                  <label for="">Name: <i class="text-danger">*</i></label>
                                  <input type="text" class="form-control" name="name" id="name" value="{{old('name')}}" required placeholder="Name">
                                </div>
                                <div class="form-group col-md-6 mt-3">
                                  <label for="">Email: <i class="text-danger">*</i></label>
                                  <input type="email" class="form-control" name="email" id="email" value="{{old('email')}}" required placeholder="Email">
                                </div>
                                <div class="form-group col-md-6 mt-3">
                                  <label for="">Company Name: <i class="text-danger">*</i></label>
                                  <input type="text" class="form-control" id="company" name="company" value="{{old('company')}}" required placeholder="Company Name">
                                </div>
                                <div class="form-group col-md-12 mt-3">
                                    <button type="submit" class="btn btn-primary">Submit</button> 
                                   
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
				
			</div>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>